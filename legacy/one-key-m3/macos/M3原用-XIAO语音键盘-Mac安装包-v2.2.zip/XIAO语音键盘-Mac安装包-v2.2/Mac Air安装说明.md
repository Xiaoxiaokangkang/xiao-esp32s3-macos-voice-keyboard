# XIAO 语音键盘——Mac Air 安装说明（v2.2 安装包）

## 安装前

- Mac 上已安装微信输入法，并保持其语音输入热键为 `Fn`。
- XIAO ESP32S3 已烧录 `XIAO Voice Keyboard V8` 固件。换电脑时不需要重新烧录。
- 本程序支持 Apple 芯片和 Intel 芯片 Mac（macOS 12 或更高版本）。

## 安装

1. 将整个 ZIP 解压，不要只拖出其中一个文件。
2. 右键点击“安装Fn Bridge.command”，选择“打开”，不要直接双击。
3. 脚本会将程序安装到 `~/Applications/Fn Bridge.app`，并添加登录自启动。
4. 在“系统设置 → 隐私与安全性 → 辅助功能”中允许 `Fn Bridge`。
5. 如果列表中没有 Fn Bridge，点 `+`，且只选择 `~/Applications/Fn Bridge.app`。如果有旧项，先删除旧项再添加这一份。
6. 将 Fn Bridge 的辅助功能开关关闭后再打开一次。程序会自动检测权限，无需重启 Mac。
7. 如果“通用 → 登录项与扩展”显示 Fn Bridge 后台项，请允许它。

## 使用

1. 插入 XIAO，等待约 3 秒。Fn Bridge 会自动将默认输入切换为 `XIAO Voice Keyboard Microphone`。
2. 把光标放入可编辑的输入框。
3. 按住设备按键说话，说完后松开，等待微信输入法输出中文。

无需完成 macOS 的键盘布局识别，如果弹出“键盘设置助理”，直接关闭即可。

Fn Bridge v2.1 会：

- 把 XIAO 内部发出的 F13 转换成微信输入法需要的 Fn。
- 插入时自动选择 XIAO 麦克风，每次按键时再次确认。
- 拔出时恢复插入前的默认麦克风。
- 在辅助功能尚未授权时留在后台等待，授权后自动生效。
- 登录 macOS 后自动运行。

## 排查

- **按键无反应**：确认辅助功能允许的是 `~/Applications/Fn Bridge.app`。按键一端必须连 XIAO `D0`，另一端连 `GND`。
- **能启动语音但没有文字**：在“系统设置 → 声音 → 输入”中查看 `XIAO Voice Keyboard Microphone` 的输入电平是否随说话变化。
- **通话软件仍使用 Mac 麦克风**：该软件可能单独锁定了输入设备，请在软件内选择“系统默认”。
- **重复安装后权限不生效**：删除辅助功能列表中的旧 Fn Bridge，再从 `~/Applications` 重新添加。
