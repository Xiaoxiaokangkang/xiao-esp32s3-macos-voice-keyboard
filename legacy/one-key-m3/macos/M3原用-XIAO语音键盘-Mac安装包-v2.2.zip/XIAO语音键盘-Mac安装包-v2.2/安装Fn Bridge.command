#!/bin/zsh
set -e

script_dir="${0:A:h}"
source_app="$script_dir/Fn Bridge.app"
install_dir="$HOME/Applications"
installed_app="$install_dir/Fn Bridge.app"
agent_dir="$HOME/Library/LaunchAgents"
agent_file="$agent_dir/com.kangkangzai.xiao-fn-bridge.plist"
user_id="$(id -u)"

if [[ ! -d "$source_app" ]]; then
  echo "找不到 Fn Bridge.app，请不要将安装脚本单独移出文件夹。"
  read -k 1 "? 按任意键退出…"
  exit 1
fi

mkdir -p "$install_dir" "$agent_dir"
pkill -x fn-bridge 2>/dev/null || true
rm -rf "$installed_app"
ditto "$source_app" "$installed_app"
xattr -dr com.apple.quarantine "$installed_app" 2>/dev/null || true

cat > "$agent_file" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.kangkangzai.xiao-fn-bridge</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/open</string>
    <string>$installed_app</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
</dict>
</plist>
PLIST

plutil -lint "$agent_file"
launchctl bootout "gui/$user_id" "$agent_file" 2>/dev/null || true
launchctl bootstrap "gui/$user_id" "$agent_file"

# launchctl 通过 open 启动 GUI App 是异步的，等待几秒再给出自检结果。
bridge_running=false
for _ in {1..10}; do
  if pgrep -x fn-bridge >/dev/null 2>&1; then
    bridge_running=true
    break
  fi
  sleep 0.5
done

open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
echo
echo "安装完成。"
if [[ "$bridge_running" == true ]]; then
  echo "Fn Bridge 运行自检：通过。"
else
  echo "Fn Bridge 运行自检：尚未启动。完成下面的权限设置后，可双击 $installed_app 启动。"
fi
echo
echo "1. 在已打开的‘辅助功能’中允许 Fn Bridge。"
echo "2. 如果列表里没有，点 + 并且只选择这一份：$installed_app"
echo "3. 如果系统询问是否允许后台项，请允许 Fn Bridge。"
echo "4. 将辅助功能开关关闭再打开一次。程序会自动检测，无需重启 Mac。"
echo
read -k 1 "? 完成授权后，按任意键关闭此窗口…"
